// stdafx.cpp : source file that includes just the standard includes
//	FiveChess.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

int m_data[15][15];