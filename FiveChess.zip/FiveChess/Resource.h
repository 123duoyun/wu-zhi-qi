//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FiveChess.rc
//
#define IDC_BOARD                       1009

#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FIVECHESS_DIALOG            102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDR_MAIN_MENU                   129
#define IDD_SETUP_DLG                   130
#define IDB_BMP_BLACK                   131
#define IDB_BMP_QP                      132
#define IDB_BMP_WHITE                   133
#define IDC_HOST_OPTION                 1000
#define IDC_CLIENT_OPTION               1001
#define IDC_IP_ADDRESS_EDIT             1002
#define IDC_NET_PORT_EDIT               1003
#define ID_NEW_GAME_MENU                32771
#define ID_DRAW_GAME_MENU               32772
#define ID_EXIT_GAME_MENU               32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
